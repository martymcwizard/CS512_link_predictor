"""
Copyright Martin McEnroe 2016
This file takes a triplet and then goes out and fetches the tSpace profile page and brings back
individual lines from that page, which are then parsed by another program
2016-04-22 refactored print statements into functions
2016-04-29 added ability to write entire returned page to allow for future parsing ideas.
2016-05-10 removed corporate password and read in from file per decode.py
TODO: update URL error codes per decode
"""

import codecs
import datetime
import re
import sys
import urllib2
import xml.etree.ElementTree as ET

fileIn = sys.argv[1] #all_triplets_20160403.txt or maybe all_0.txt
fileOut = sys.argv[2] #profile_sentences.txt
fileStatus = sys.argv[3] #output progress
fileErrors = sys.argv[4] #output errors
xmlOUT = sys.argv[5] #use to save the entire tSpace response

fmypw = '/opt/data/share05/sandbox/sandbox47/myplp/64encodedpw.txt'
fmp = open(fmypw, 'r')
mypw = fmp.readline().rstrip('\n')
fmp.close

user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
headers = { 'Authorization': mypw }

def print_time(text = 'time'):
    fs = open(fileStatus, 'a+')
    fs.write(str(text) + ' Timestamp: {:%Y-%m-%d %H:%M:%S:%f}'.format(datetime.datetime.now()) + '\n')
    fs.close()
    return

def print_error(text = 'error'):
    fe = open(fileStatus, 'a+')
    fe.write('Timestamp: {:%Y-%m-%d %H:%M:%S:%f}'.format(datetime.datetime.now()))
    fe.write(text + '\n')
    fe.close()
    return

def get_url(uid, tID, num):
    url = 'https://tspace.web.att.com/connections/opensocial/basic/rest/\
activitystreams/urn:lsid:lconn.ibm.com:profiles.person:%s/@involved/\
@all?rollup=true&shortStrings=true&format=atom' % tID
    try:
        t_p = urllib2.urlopen(urllib2.Request(url, None, headers)).read()
        return [t_p]
    except urllib2.HTTPError, e:
        error_string = 'We failed with error code - %s.' % e.code + 'on attempt ' + str(num) + ' for attuid ' + attuid
        print_error(error_string)
        if e.code == 404 or e.code == 401 or e.code == 403:
            return [False]
        else:
            return [1]
    except urllib2.URLError, e: #everything will fail
        print_error(e.reason)
        #print "Connect your computer/VPN dummy"
        fi.close()
        return [False]

print_time('starting')

fi = open(fileIn, 'r')
num_lines = sum(1 for line in fi)
#print num_lines

fi = open(fileIn, 'r')
fX = codecs.open(xmlOUT, 'w', encoding='utf-8')

with codecs.open(fileOut, 'w', encoding='utf-8') as f:
    for line in range(0, num_lines):
        try:
            attuid, attname, tSpaceID = fi.readline().rstrip('\n').split('|')
        except ValueError:
            print_error(attuid + " there is a mismatch in number of values in the triplet file " + str(line) + '\n')
            continue
        except:
            print_error(attuid + " is probably the last good one, unexpected error on line: " + str(line) + sys.exc_info()[0] +'\n')
            fi.close()
            raise

        for k in range(1,4):
            if k >= 2:
                print k
            result = get_url(attuid, tSpaceID, k)
            if type(result[0]) == str:
                #print type(result[0])
                break
            elif result[0] == False:
                #print result, '404 code', line, attuid, tSpaceID, k
                k = 4
                break # exit loop
            elif result == [1]:
                #print result, '401 code', line, attuid, tSpaceID, k
                continue
            else:
                pass
                #print 'What just happened?', type(result[0]), result[0]

        if result[0] == False or result[0] == 1:
            continue #means go get the next line (instead of entering that ridiculous infinite while loop)
        #print line #'we should only be here if we have a page, sometimes not parsable, don\'t know why'
        the_page = result[0]
        try: #some of the returned pages fail to parse
            root = ET.fromstring(the_page)
        except ET.ParseError:
            print_error('skipping ' + attuid + 'failed parsing on line number: ' + str(line))
        except:
            print_error(attuid + 'Unexpected error on line: ' + str(line) + sys.exc_info()[0])
            fi.close()
            raise

        for child in root:
            title = ''
            updated = ''
            for L2 in child:
                #print
                #print 'L2', L2
                tag2 = re.search(r'(\{.*\})(.*)',str(L2.tag)).group(2)
                if tag2 == 'title':
                    title = L2.text
                elif tag2 == 'updated':
                    updated = L2.text
                #print ' Title = ', title, 'update = ', updated

            if title != '' and updated != '':
                f.write(attuid + '|' + title + '|' + updated + '\n')
        try:
            fX.write(attuid + '|' + the_page + '\n') #2016-04-29
        except UnicodeEncodeError, err:
            error_string = attuid + '|' err
            print_error(error_string)
        

        if line % 1000.0 == 0:
            print_time(line)
print_time('Completed')
fX.close()
fi.close()