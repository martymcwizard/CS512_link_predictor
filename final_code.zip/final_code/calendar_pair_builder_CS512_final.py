"""
Copyright Martin McEnroe 2016
2016-05-10 was called clist_builder_2.py
"""
#this is to build the dictionary of counts and to validate the id exists

import sys
from itertools import combinations

F_dict = dict()
M_dict = dict()


fileIn0 = sys.argv[3] #valid_attuids.txt
fileIn1 = sys.argv[1] #feb_less_april_clear
fileIn2 = sys.argv[2] #mar_clear.txt

fileOut1 = sys.argv[4] #t_pairs_clear.feb
fileOut2 = sys.argv[5] #t_uniq_pairs_clear.mar

with open(fileIn0) as fv:
    valid_attuids = fv.read().splitlines()

#print len(valid_attuids)

v_a = {}
for i in xrange(len(valid_attuids)):
    v_a[valid_attuids[i]] = 1
print 'length of valid', len(v_a)

fi = open(fileIn1, 'r')
num_lines = sum(1 for line in fi)
fi.close()
print 'Number of lines in training data', num_lines

foF = open(fileOut1, 'w+')
fi = open(fileIn1, 'r')
for line in range(0, num_lines): #num_lines):
    inline = [i for i in fi.readline().rstrip('\n').split('|')]
    aidline = [i for i in inline if i in v_a] #can it really be that simple to validate the attuid?
    aidline = sorted(set(aidline), reverse = False)
    for c in combinations(aidline,2):
        c = sorted(c, reverse = False)
        #print 'combination = ', c
        cstr = c[0] + c[1]
        #print cstr
        if cstr in F_dict:
            F_dict[cstr] += 1
        else:
            F_dict[cstr] = 1

print 'Number of lines packed into a dictionary from first file', len(F_dict)
for key, value in F_dict.iteritems():
    foF.write(key[:6] + '|' + key[-6:] + '|' + str(value) + '\n')

foF.close()
fi.close()

fi = open(fileIn2, 'r')
num_lines = sum(1 for line in fi)
fi.close()
print 'Number of rows in test data', num_lines

foR = open(fileOut2, 'w+')
fi = open(fileIn2, 'r')
for line in range(0, num_lines): #num_lines):
    inline = [i for i in fi.readline().rstrip('\n').split('|')]
    aidline = [i for i in inline if i in v_a] #can it really be that simple to validate the attuid?
    aidline = sorted(set(aidline), reverse = False)

    for c in combinations(aidline,2):
        #print c
        c = sorted(c, reverse = False)
        #print 'sorted', c
        cstr = c[0] + c[1]
        if cstr not in F_dict:
            if cstr in M_dict:
                M_dict[cstr] += 1
            else:
                M_dict[cstr] = 1

print 'Number of lines packed into a dictionary from first and second file', len(F_dict)
for key, value in M_dict.iteritems():
    foR.write(key[:6] + '|' + key[-6:] + '|' + str(value) + '\n')
print 'Number of new, unique pairs in test data: ', len(M_dict)

foR.close()
fi.close()