"""
Copyright Martin McEnroe 2016
2016-05-10 was originally called MatchFinalv3.py
"""

import re
import sys
name2id  = {}

fileIn =  sys.argv[1] #was 'id_name_triples.txt' 'id_lower.txt'
fileIn2 = sys.argv[2] #'all_tS.txt' 
fileOut =  sys.argv[3] #'testing_lower_out.txt'
fo = open(fileOut, 'w+')

def match_names(c, k = 8, c_parts = [], testname = '', aid = 'NoMATCH'):
    c_parts = [i for i in c.split()]
    for m in range(min(len(c_parts),k), 1, -1):
        testname = ''
        for j in range(0,m):
            testname += ' ' + c_parts[j] #this is key, to match the new id_lower.txt file
        if testname.lstrip().lower() in name2id:
            aid = name2id[testname.lstrip().lower()]
            break
    nu_comment = c.replace(testname.lstrip() + ' ', '', 1)
    return aid, nu_comment, testname.lstrip()

#make the name/attuid dictionary
fi = open(fileIn, 'r')
num_lines = sum(1 for line in fi)
fi.close()
fi = open(fileIn, 'r')
for line in range(0, num_lines):#num_lines):
    try: #some people have commas in their name like Mark T. Hopkins, Ph.d. Hopkins
        inline = [i for i in fi.readline().rstrip('\n').split('|')] 
    except ValueError:
        print(attuid, "I DON'T KNOW WHAT is GOING ON ", line)
        continue
    except:
        print(attuid, "REALLY, no idea,", line, sys.exc_info()[0])
        fi.close()
        raise
    #this code is an artifact of me using commas in my intermediate file instead of the pipe character
    if len(inline) == 2:
        [attuid, attname] = [i for i in inline]
    else: #len(inline) == 4:
        print(attuid, "I DON'T KNOW WHAT is GOING ON - everything should be length 2", line)
    name2id[attname] = attuid
fi.close()

#get some lines from the comment file
fo = open(fileOut, 'w+')
fi = open(fileIn2, 'r')
num_lines = sum(1 for line in fi)
fi.close()

fi = open(fileIn2, 'r')
for line in range(0, num_lines):
    inline = [i for i in fi.readline().rstrip('\n').split('|')]
    attuid_1 = inline[0]
    comment = inline[1] #sometimes there are extra | in the comment. we can just ignore it
    #print comment
    timestamp = inline[-1]
    #this is the first step to pull out the beginning name
    attuid_2, gnu_comment, lastcheckedname = match_names(comment) #last checked name was just for debugging
    
    #print attuid_2, gnu_comment, lastcheckedname
    if len(gnu_comment.split(None,1)) > 1:
        verb, rest_of_comment = gnu_comment.split(None, 1)
    else:
        verb = gnu_comment

    if verb == 'mentioned':
        outline = timestamp + '|' + verb + '|' + attuid_1 + '|' + attuid_2
        if len(rest_of_comment.split(' in a',1)) > 1:
            name_string, garbage = rest_of_comment.split('in a',1)
        else:
            print 'some mess', rest_of_comment   
            
        if len(name_string.split(' and ',1)) > 1:
            uptothree, last = name_string.split(' and ',1)
            splitnames = uptothree.split(', ')
            if re.search(r'other',last) == None:
                splitnames.append(last.rstrip())
            for name in splitnames:
                splitid, nothing, lastcheckedname = match_names(name)
                outline += '|' + splitid
            fo.write(outline + '\n')
        else:
            #there should be only one name here
            name = name_string.rstrip()
            splitid, nothing, lastcheckedname = match_names(name)
            outline += '|' + splitid
            fo.write(outline + '\n')
    elif verb == 'liked':
        if len(rest_of_comment.split(None,2)) > 2:
            one, two, more = rest_of_comment.split(None,2)
            if one == 'a' and two == 'reply':
                verb = 'liked_a_reply'
                outline = timestamp + '|' + verb + '|' + attuid_1 + '|' + attuid_2
                fo.write(outline + '\n')
            elif one == 'an' and two == 'OLE':
                verb = 'liked_an_OLE_article'
                outline = timestamp + '|' + verb + '|' + attuid_1 + '|' + attuid_2
                fo.write(outline + '\n')
            else:
                one_name_comment = rest_of_comment.split('\'',1)
                attuid_3, gnu_comment, lastcheckedname = match_names(one_name_comment[0], len(one_name_comment[0]))
                outline = timestamp + '|' + verb + '|' + attuid_1 + '|' + attuid_2 + '|' + attuid_3
                fo.write(outline + '\n')
    elif verb == 'commented':
        one, two = rest_of_comment.split('on',1)
        one_name_comment = two.split('\'',1)
        attuid_3, gnu_comment, lastcheckedname = match_names(one_name_comment[0], len(one_name_comment[0]))
        outline = timestamp + '|' + verb + '|' + attuid_1 + '|' + attuid_2 + '|' + attuid_3
        fo.write(outline + '\n')
    elif verb in ['created', 'replied', 'contributed', 'edited', 'updated', 'posted']:
        outline = timestamp + '|' + verb + '|' + attuid_1 + '|' + attuid_2
        fo.write(outline + '\n')
    else:
        if len(verb) >= 1:
            short_verb = verb[0]
        outline = timestamp + '|' + short_verb + '|' + attuid_1
        fo.write(outline + '\n')
    #print(outline + '\n')
print num_lines
fi.close()
fo.close()