"""
Copyright Martin McEnroe 2016
"""

import datetime
import random
import re
import sys
import time
import urllib2

fileIn = sys.argv[1] #all_triplets_20160403.txt or maybe all_0.txt
fileOut = sys.argv[2] #triplets.txt
fileStatus = sys.argv[3] #output progress
fileErrors = sys.argv[4] #output errors

fmypw = '/opt/data/share05/sandbox/sandbox47/myplp/64encodedpw.txt'
fmp = open(fmypw, 'r')
mypw = fmp.readline().rstrip('\n')
fmp.close

user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
headers = { 'Authorization': mypw }

def print_time(text = 'time'):
    fs = open(fileStatus, 'a+')
    fs.write(str(text) + ' Timestamp: {:%Y-%m-%d %H:%M:%S:%f}'.format(datetime.datetime.now()) + '\n')
    fs.close()
    return

def print_error(text = 'error'):
    fe = open(fileStatus, 'a+')
    fe.write('Timestamp: {:%Y-%m-%d %H:%M:%S:%f}'.format(datetime.datetime.now()))
    fe.write(' ' + text + '\n')
    fe.close()
    return

def get_url(uid, num):
    url = 'https://tspace.web.att.com/profiles/atom/profile.do?email=%s@att.com' % uid
    try:
        t_p = urllib2.urlopen(urllib2.Request(url, None, headers)).read()
        return [t_p]
    except urllib2.HTTPError, e:    #wow, there is a urllib3!
        error_string = 'We failed with error code - %s.' % e.code + 'on attempt ' + str(num) + ' for attuid ' + attuid
        print_error(error_string)
        if e.code == 404 or e.code == 401 or e.code == 403:
            return [False]
        else:
            return [1]
    except urllib2.URLError, e: #everything will fail
        if type(e.reason) == type('string'):
            print_error(e.reason)
        else: 
            print_error('urllib2.URLError reason was not a string on attuid' + attuid)
        return [False] #what else could it be?
        #fi.close()
        #raise
    except (IOError, httplib.HTTPException):
        if type(e.reason) == type('string'):
            print_error(e.reason)
        else: 
            print_error('httplib.HTTPException reason was not a string on attuid' + attuid)            
        return [False]

print_time('starting')

fo = open(fileOut, 'w+')        # output file
#fb = open(fileErrors, 'w+') # 'b' stands for bad - we were not able to fetch a tSpace ID for these

fi = open(fileIn, 'r')         # input file
num_lines = sum(1 for line in fi)
fi.close()

fi = open(fileIn, 'r')
for line in range(0, num_lines):#num_lines):
    attuid = fi.readline().rstrip('\n')

    for k in range(1,4): #we will try three times before giving up
        result = get_url(attuid, k)
        if type(result[0]) == str:
            #print type(result[0])
            break #we got a match!  move on
        elif result[0] == False:
            #print result, '404 code', line, attuid, k #this is page not found, it will never be found!
            k = 4
            break # exit loop
        elif result == [1]:
            #print result, '401 code', line, attuid, k
            continue
        else:
            pass
            #print 'What just happened?', type(result[0]), result[0]

    if result[0] == False or result[0] == 1:  #I forgot what this means
        continue

    #print type(result), result
    #print type(result[0]), result[0]

    f2 = re.search(r'(<contributor><name>)(.*)(</name>)', result[0])  #this is the tSpace name
    if f2 != None:
        f2g = f2.group(2)
    else:
    #    print 'attuid', attuid, 'failed on name'
        error_string = attuid + ', name'
        print_error(error_string)

    f3 = re.search(r'(<snx:userid>)(.{36})(</snx:userid>)', result[0]) #this is the tSpace key we will use to scrape profile
    if f3 != None:
        f3g = f3.group(2)
    #else:
    #    print 'attuid', attuid, 'failed on first key - important'
    #    error_string = attuid + ', key\n'
    #    print_error(error_string)

    #f4 = re.search(r'(<div class="x-profile-key">)(.{36})(</div>)', the_page) #this is used for the RSS feed
    #if f4 != None:
    #    f4g = f4.group(2)
    #else:
    #    print 'attuid', attuid, 'failed on second key - not important'
    #    fb.write(attuid + '\n')

    fo.write(attuid + '|' + f2g + '|' + f3g + '\n')

    if line % 1000.0 == 0:
        print_time(line)

print_time('finish')

fo.close()
#fb.close()
fi.close()