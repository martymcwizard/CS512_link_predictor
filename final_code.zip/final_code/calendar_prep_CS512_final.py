"""
Copyright Martin McEnroe 2016
2016-05-10 Was called ./Cal_post/gnu_cal_5.py
"""

import sys
import datetime
import hashlib
import re

fsalt = '/opt/data/share05/sandbox/sandbox47/myplp/salt.txt'
fs = open(fsalt, 'r')
salt = fs.readline().rstrip('\n')
fs.close

def anon(anything):
    return hashlib.sha256(anything+salt).hexdigest()[-12:]

#2016-04-23 this is where i would get clever about research and directtv
def uid_strip(emails, temp):
    for j in emails.split(';'):
        if re.search(r'(.*)(@att.com)', j.lower()) != None:
            #move the anon step until after the chain calculation
            #temp.append(anon(re.search(r'(.*)(@att.com)', j.lower()).group(1)[-6:]))
            temp.append(re.search(r'(.*)(@att.com)', j.lower()).group(1)[-6:])
    if temp == []: #there are now @att.com in the list
        return ''
    else:
        return ';'.join(i for i in temp)

def clean(il):
    good_list = range(5)
    good_list[0] = il[3]
    good_list[1] = uid_strip(il[0],[])
    good_list[2] = uid_strip(il[8],[])
    good_list[3] = uid_strip(il[9],[])
    good_list[4] = uid_strip(il[16],[])
    return ';'.join(i for i in good_list)

fileIn = sys.argv[1] #this is a pipe delimited calendar file!
fileOut = sys.argv[2] # a ; delimited attuid file

fi = open(fileIn, 'r')
num_lines = sum(1 for line in fi)
fi.close()

fo = open(fileOut, 'w+')
fi = open(fileIn, 'r')
for line in range(0, num_lines): #num_lines):
    inline = [i for i in fi.readline().rstrip('\n').split('|')]
    ole = sorted(set(clean(inline).split(';')), reverse = False)
    fo.write('|'.join(i for i in ole if i != '') + '\n')

fi.close()
fo.close()