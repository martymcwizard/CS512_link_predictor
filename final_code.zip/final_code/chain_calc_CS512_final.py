"""
Copyright Martin McEnroe 2016
2016-05-10 was called chain_calc_cal_3.py
"""

import sys
import datetime
import hashlib
import re

fsalt = '/opt/data/share05/sandbox/sandbox47/myplp/salt.txt'
fs = open(fsalt, 'r')
salt = fs.readline().rstrip('\n')
fs.close

fileIn = sys.argv[1] #the output of c_list builder such as c_pairs_clear.feb
fileClear = sys.argv[2] #really useful for debugging, can't leave lake c_pairs_clear_scored.feb
fileAnon = sys.argv[3] #file to use for class c_pairs_anon_scored.feb

def anon(anything):
    return hashlib.sha256(anything+salt).hexdigest()[-12:]

#this is working with cleartext ids
with open('cogs.txt') as f:
    chains = f.read().splitlines()

coc = {}
for i in xrange(len(chains)):
    chain_list = []
    while len(chains[i]) > 0:
        chain_list.append(chains[i][-6:])
        chains[i] = chains[i][:-6]
    try:
        coc[chain_list[0]] = chain_list #some lines are blank?
    except:
        continue

print 'length of coc dictionary', len(coc)

fo = open(fileClear, 'w+')
fa = open(fileAnon, 'w+')

with open(fileIn) as f:
    pairs = f.read().splitlines()

for i in xrange(len(pairs)):
#for i in range(0,100):
    peep1, peep2, count = pairs[i].split('|')
    if peep1 not in coc:  #should be unusual because I checked these already
        #print peep1
        continue
    if peep2 not in coc:
        #print peep2
        continue
    chain1 = coc[peep1]
    chain2 = coc[peep2]
    try:
        match_peeps = [val for val in chain1 if val in chain2][0]
        r = chain1.index(match_peeps)
        m = chain2.index(match_peeps)
    except:
        r = len(chain1)
        m = len(chain2)

    distance = r + m
    path = 'r'*r + 'm'*m

    fo.write(peep1 + '|' + peep2 + '|' + path + '|' + str(distance) + '|' + str(count) + '\n')
    fa.write(anon(peep1) + '|' + anon(peep2) + '|' + path + '|' + str(distance) + '|' + str(count) + '\n')

fo.close()
fa.close()